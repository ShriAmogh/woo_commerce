<?php
/**
 * Custom REST API endpoints for WooCommerce AI Chatbot.
 * Provides a way for the Python agent to update the user's cart (draft order)
 * without direct dependency on the browser session for every call.
 */

if (!defined('ABSPATH'))
    exit;

add_action('rest_api_init', function () {
    register_rest_route('woo-chatbot/v1', '/cart/add', [
        'methods' => 'POST',
        'callback' => 'woochat_rest_add_to_cart',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('woo-chatbot/v1', '/cart/get', [
        'methods' => 'GET',
        'callback' => 'woochat_rest_get_cart',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('woo-chatbot/v1', '/cart/remove', [
        'methods' => 'POST',
        'callback' => 'woochat_rest_remove_from_cart',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route('woo-chatbot/v1', '/cart/update', [
        'methods' => 'POST',
        'callback' => 'woochat_rest_update_cart',
        'permission_callback' => '__return_true',
    ]);
});

/**
 * REST Callback: Adds a product to a persistent draft order for a session.
 */
function woochat_rest_add_to_cart($request)
{
    $params = $request->get_json_params();
    $session_id = isset($params['session_id']) ? sanitize_text_field($params['session_id']) : '';
    $user_id    = isset($params['user_id'])    ? (int)$params['user_id']    : 0;
    $product_id = isset($params['product_id']) ? (int)$params['product_id'] : 0;
    $quantity = isset($params['quantity']) ? (int)$params['quantity'] : 1;

    if (empty($session_id) || !$product_id) {
        return new WP_Error('missing_params', 'Session ID and Product ID are required.', ['status' => 400]);
    }

    // 1. Get or create the draft order
    $order = woochat_get_or_create_draft_order($session_id, $user_id);
    if (is_wp_error($order)) {
        return $order;
    }

    // 2. Add/Update item in the order
    $found = false;
    foreach ($order->get_items() as $item_id => $item) {
        // If the ID matches either the parent_id or variation_id, we count it as a match
        $item_product_id = (int)$item->get_product_id();
        $item_variation_id = (int)$item->get_variation_id();

        if ($item_product_id === $product_id || $item_variation_id === $product_id) {
            $item->set_quantity($item->get_quantity() + $quantity);
            $item->save();
            $found = true;
            break;
        }
    }

    if (!$found) {
        $product = wc_get_product($product_id);
        if (!$product) {
            return new WP_Error('invalid_product', 'Product not found.', ['status' => 404]);
        }

        // If it's a variable product, pick the first valid variation if none specified
        if ($product->is_type('variable')) {
            $variations = $product->get_available_variations();
            if (!empty($variations)) {
                $product_id = $variations[0]['variation_id'];
                $product = wc_get_product($product_id);
            }
        }
        
        $order->add_product($product, $quantity);
    }

    $order->calculate_totals();
    $order->save();

    return rest_ensure_response([
        'success' => true,
        'order_id' => $order->get_id(),
        'item_count' => $order->get_item_count(),
        'total' => $order->get_total(),
        'checkout_url' => wc_get_checkout_url(),
    ]);
}

/**
 * REST Callback: Retrieves the draft order ID for a session.
 */
function woochat_rest_get_cart($request)
{
    $session_id = sanitize_text_field($request->get_param('session_id'));
    $user_id    = (int)$request->get_param('user_id');
    if (empty($session_id)) {
        return new WP_Error('missing_session', 'Session ID is required.', ['status' => 400]);
    }

    $order = woochat_get_or_create_draft_order($session_id, $user_id);
    if (is_wp_error($order)) {
        return $order;
    }

    return rest_ensure_response([
        'success' => true,
        'order_id' => $order->get_id(),
        'checkout_url' => wc_get_checkout_url(),
    ]);
}

/**
 * REST Callback: Removes a product from the draft order.
 * Supports partial removal (quantity) and variation matching.
 */
function woochat_rest_remove_from_cart($request)
{
    $params = $request->get_json_params();
    $session_id = isset($params['session_id']) ? sanitize_text_field($params['session_id']) : '';
    $user_id    = isset($params['user_id'])    ? (int)$params['user_id']    : 0;
    $product_id = isset($params['product_id']) ? (int)$params['product_id'] : 0;
    $quantity = isset($params['quantity']) ? (int)$params['quantity'] : -1; // -1 means remove all

    if (empty($session_id) || !$product_id) {
        return new WP_Error('missing_params', 'Session ID and Product ID are required.', ['status' => 400]);
    }

    $order = woochat_get_or_create_draft_order($session_id, $user_id);
    if (is_wp_error($order)) {
        return $order;
    }

    foreach ($order->get_items() as $item_id => $item) {
        $item_product_id = (int)$item->get_product_id();
        $item_variation_id = (int)$item->get_variation_id();

        if ($item_product_id === $product_id || $item_variation_id === $product_id) {
            if ($quantity === -1) {
                $order->remove_item($item_id);
            }
            else {
                $current_qty = $item->get_quantity();
                $new_qty = max(0, $current_qty - $quantity);

                if ($new_qty === 0) {
                    $order->remove_item($item_id);
                }
                else {
                    $item->set_quantity($new_qty);
                    $item->save();
                }
            }
            break;
        }
    }

    $order->calculate_totals();
    $order->save();

    return rest_ensure_response([
        'success' => true,
        'order_id' => $order->get_id(),
        'item_count' => $order->get_item_count(),
        'total' => $order->get_total(),
    ]);
}

/**
 * REST Callback: Updates a product's absolute quantity in the draft order.
 */
function woochat_rest_update_cart($request)
{
    $params = $request->get_json_params();
    $session_id = isset($params['session_id']) ? sanitize_text_field($params['session_id']) : '';
    $user_id    = isset($params['user_id'])    ? (int)$params['user_id']    : 0;
    $product_id = isset($params['product_id']) ? (int)$params['product_id'] : 0;
    $quantity = isset($params['quantity']) ? (int)$params['quantity'] : 0;

    if (empty($session_id) || !$product_id) {
        return new WP_Error('missing_params', 'Session ID and Product ID are required.', ['status' => 400]);
    }

    $order = woochat_get_or_create_draft_order($session_id, $user_id);
    if (is_wp_error($order)) {
        return $order;
    }

    $found = false;
    foreach ($order->get_items() as $item_id => $item) {
        $item_product_id = (int)$item->get_product_id();
        $item_variation_id = (int)$item->get_variation_id();

        if ($item_product_id === $product_id || $item_variation_id === $product_id) {
            if ($quantity <= 0) {
                $order->remove_item($item_id);
            }
            else {
                $item->set_quantity($quantity);
                $item->save();
            }
            $found = true;
            break;
        }
    }

    // If not found and quantity > 0, add it
    if (!$found && $quantity > 0) {
        $product = wc_get_product($product_id);
        if ($product) {
            $order->add_product($product, $quantity);
        }
    }

    $order->calculate_totals();
    $order->save();

    return rest_ensure_response([
        'success' => true,
        'order_id' => $order->get_id(),
        'item_count' => $order->get_item_count(),
        'total' => $order->get_total(),
    ]);
}

/**
 * Helper: Finds a draft order for a session or creates a new one.
 */
function woochat_get_or_create_draft_order($session_id, $user_id = 0)
{
    $args = [
        'status' => 'pending', // We use pending as the draft state
        'limit' => 1,
        'meta_key' => '_woochat_session_id',
        'meta_value' => $session_id,
        'orderby' => 'date',
        'order' => 'DESC',
    ];

    $orders = wc_get_orders($args);

    if (!empty($orders)) {
        $order = $orders[0];
        // If order exists but has no customer and we now have a user_id, link them
        if ( ! $order->get_customer_id() && $user_id ) {
            $order->set_customer_id( $user_id );
            $order->save();
        }
        return $order;
    }

    // Create new order
    $order = wc_create_order([
        'status' => 'pending',
        'customer_id' => $user_id, // Guest initially (0) or logged-in user
    ]);

    if (is_wp_error($order)) {
        return $order;
    }

    $order->update_meta_data('_woochat_session_id', $session_id);
    $order->save();

    return $order;
}